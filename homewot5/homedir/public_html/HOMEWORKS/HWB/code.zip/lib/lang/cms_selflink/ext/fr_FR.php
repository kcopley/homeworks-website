<?php
$lang['prev_label'] = 'Page pr&eacute;c&eacute;dente&nbsp;:';
$lang['next_label'] = 'Page suivante&nbsp;:';
$lang['utmz'] = '156861353.1285516504.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-668387697-1285516504892';
$lang['utma'] = '156861353.1307470949.1285516504.1285516504.1285518674.2';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>