<?php
$lang['automatedtask_failed'] = 'Automated Task Failed';
$lang['automatedtask_success'] = 'Automated Task Success';
$lang['clearcache_taskname'] = 'Clear Cache Files';
$lang['clearcache_taskdescription'] = 'Automatically clear files from cache directory that are older than a preset number of days';
$lang['testme'] = 'HAHA';
$lang['utmz'] = '156861353.1276867169.75.59.utmccn=(referral)|utmcsr=forum.cmsmadesimple.org|utmcct=/index.php|utmcmd=referral';
$lang['utma'] = '156861353.2011971019.1267148164.1277419531.1277422879.77';
$lang['qca'] = 'P0-1764775436-1267108330132';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>