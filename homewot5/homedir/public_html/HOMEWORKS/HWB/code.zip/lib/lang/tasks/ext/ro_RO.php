<?php
$lang['automatedtask_failed'] = 'Sarcina automata a esuat';
$lang['automatedtask_success'] = 'Sarcina automata rulata cu succes';
$lang['clearcache_taskname'] = 'Stergere Fisiere Cache';
$lang['clearcache_taskdescription'] = 'Stergere automata a fisierelor din folderul cache care sunt mai vechi decat numarul de zile setat';
$lang['testme'] = 'yup a luat-o';
$lang['qca'] = 'P0-1838215043-1282807533934';
$lang['utmz'] = '156861353.1282807972.1.2.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms';
$lang['utma'] = '156861353.1191873817.1282807534.1282807534.1282807534.1';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.12.9.1282807615368';
?>