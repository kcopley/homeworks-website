<?php
$lang['automatedtask_failed'] = '&Eacute;chec de l&#039;ex&eacute;cution des t&acirc;ches automatiques';
$lang['automatedtask_success'] = 'T&acirc;che automatique ex&eacute;cut&eacute;e';
$lang['clearcache_taskname'] = 'Effacement des fichiers mis en cache';
$lang['clearcache_taskdescription'] = 'Effacer automatiquement les fichiers mis en cache qui sont plus anciens que le nombre de jour d&eacute;fini.';
$lang['testme'] = 'Yep';
$lang['utmz'] = '156861353.1278169512.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utma'] = '156861353.1474388897.1278169512.1278169512.1278175547.2';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>