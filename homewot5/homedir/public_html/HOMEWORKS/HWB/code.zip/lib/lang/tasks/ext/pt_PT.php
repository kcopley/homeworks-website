<?php
$lang['automatedtask_failed'] = 'Tarefa autom&aacute;tica falhou';
$lang['automatedtask_success'] = 'Tarefa autom&aacute;tica com sucesso';
$lang['clearcache_taskname'] = 'Esvaziar cache';
$lang['clearcache_taskdescription'] = 'Automaticamente esvazia o cache a partir do direct&oacute;rio de cache que s&atilde;o mais antigos do que um n&uacute;mero predefinido de dias';
$lang['testme'] = 'woot got it ';
$lang['qca'] = 'P0-1236842016-1276975567163';
$lang['utma'] = '156861353.1127963369.1277311597.1278072220.1278188876.23';
$lang['utmz'] = '156861353.1277858169.17.5.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['utmb'] = '156861353.1.10.1278188876';
$lang['utmc'] = '156861353';
?>