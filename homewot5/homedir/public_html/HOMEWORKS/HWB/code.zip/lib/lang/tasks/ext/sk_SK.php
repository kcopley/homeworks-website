<?php
$lang['automatedtask_failed'] = 'Automatizoan&yacute; task s chybou';
$lang['automatedtask_success'] = 'Automatizoan&yacute; task &uacute;spe&scaron;n&yacute;';
$lang['clearcache_taskname'] = 'Vyčistiť ke&scaron;ovan&eacute; s&uacute;bory';
$lang['clearcache_taskdescription'] = 'Automatick&eacute; mazanie ke&scaron;ovanych s&uacute;bor star&scaron;&iacute;ch ako nastavenie dn&iacute; v nastaveniach';
$lang['testme'] = 'm&aacute;me to';
$lang['utma'] = '156861353.1423109725.1280259016.1283630846.1283679544.29';
$lang['utmz'] = '156861353.1283630846.28.27.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/';
$lang['qca'] = 'P0-748439131-1280259017524';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>