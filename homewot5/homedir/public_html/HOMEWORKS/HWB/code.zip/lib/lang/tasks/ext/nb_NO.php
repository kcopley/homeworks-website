<?php
$lang['automatedtask_failed'] = 'Automatisk oppgavekj&oslash;ring mislyktes';
$lang['automatedtask_success'] = 'Automatisk oppgavekj&oslash;ring vellykket';
$lang['clearcache_taskname'] = 'Rens av mellomlagrede filer';
$lang['clearcache_taskdescription'] = 'Rens filer fra /cache katalogen som er eldre enn et forh&aring;ndsatt antall dager';
$lang['testme'] = 'Jippy - fikk det til!';
$lang['utmz'] = '156861353.1274726983.2794.62.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/bug/view/4955';
$lang['utma'] = '156861353.179052623084110100.1210423577.1277505175.1277545505.2931';
$lang['qca'] = '1210971690-27308073-81952832';
$lang['utmb'] = '156861353.2.10.1277545505';
$lang['utmc'] = '156861353';
?>