<?php
$lang['automatedtask_failed'] = 'Automatisk uppgift misslyckades';
$lang['automatedtask_success'] = 'Automatisk uppgift lyckades';
$lang['clearcache_taskname'] = 'Rensa cache filer';
$lang['clearcache_taskdescription'] = 'Automatiskt rensa filer fr&aring;n cachekatalogen som &auml;r &auml;ldre &auml;n ett f&ouml;rinst&auml;llt antal dagar';
$lang['testme'] = 'va fick den';
$lang['utma'] = '156861353.622613290.1282068801.1286168190.1286206126.26';
$lang['utmz'] = '156861353.1284652314.14.4.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['qca'] = 'P0-1267218368-1282068801788';
$lang['utmb'] = '156861353.1.10.1286206126';
$lang['utmc'] = '156861353';
?>