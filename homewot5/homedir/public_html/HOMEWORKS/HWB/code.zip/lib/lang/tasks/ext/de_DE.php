<?php
$lang['automatedtask_failed'] = 'Automatisierte Aufgabe fehlgeschlagen';
$lang['automatedtask_success'] = 'Automatisierte Aufgabe erledigt';
$lang['clearcache_taskname'] = 'Zwischengespeicherte Dateien l&ouml;schen';
$lang['clearcache_taskdescription'] = 'L&ouml;scht alle Dateien aus dem Verzeichnis /tmp/cache und tmp/templates_c, die &auml;lter sind als die voreingestellte Anzahl an Tagen';
$lang['testme'] = 'Erledigt';
$lang['utma'] = '156861353.864112358.1277805270.1277805270.1277805270.1';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1277805270.1.1.utmccn=(referral)|utmcsr=forum.cmsmadesimple.org|utmcct=/index.php|utmcmd=referral';
?>