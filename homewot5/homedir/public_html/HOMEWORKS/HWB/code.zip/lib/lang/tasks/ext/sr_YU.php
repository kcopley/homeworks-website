<?php
$lang['automatedtask_failed'] = 'Automatizovani zadatak nije uspeo';
$lang['automatedtask_success'] = 'Automatizovani zadatak je bio uspe&scaron;an';
$lang['clearcache_taskname'] = 'Ispraznite ke&scaron; datoteke';
$lang['clearcache_taskdescription'] = 'Automatski ispraznite datoteke iz direktorijuma ke&scaron;a koje su starije od određenog broja dana';
$lang['testme'] = 'Juhu, uspelo je!';
$lang['qca'] = 'P0-2062649571-1290608225500';
$lang['utmz'] = '156861353.1290691952.4.3.utmcsr=forum.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/index.php';
$lang['utma'] = '156861353.1878528924.1290608225.1290867463.1290888988.12';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>