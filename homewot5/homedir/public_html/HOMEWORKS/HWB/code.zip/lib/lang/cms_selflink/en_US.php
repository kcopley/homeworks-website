<?php
$lang['prev_label'] = 'Previous page:';
$lang['next_label'] = 'Next page:';
?>