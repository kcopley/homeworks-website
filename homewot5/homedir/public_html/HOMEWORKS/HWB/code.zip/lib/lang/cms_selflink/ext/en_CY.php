<?php
$lang['prev_label'] = 'Tudalen Flaenorol:';
$lang['next_label'] = 'Tudalen nesaf:';
$lang['qca'] = 'P0-1616678321-1262603060110';
$lang['utmz'] = '156861353.1287489336.33.6.utmcsr=wiki.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/index.php/Special:Search';
$lang['utma'] = '156861353.1150550259.1285890669.1287828027.1287832831.47';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.4.9.1287834037426';
?>