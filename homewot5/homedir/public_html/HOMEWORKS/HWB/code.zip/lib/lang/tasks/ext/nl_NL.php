<?php
$lang['automatedtask_failed'] = 'Geautomatiseerde taak mislukt';
$lang['automatedtask_success'] = 'Geautomatiseerde taak geslaagd';
$lang['clearcache_taskname'] = 'Gebufferde bestanden verwijderd (Clear Cache)';
$lang['clearcache_taskdescription'] = 'Verwijder automatisch de bestanden in de Cache servermap die ouder zijn dan de ingestelde dagen';
$lang['testme'] = 'Gevonden!';
$lang['utma'] = '156861353.2094334740.1272799615.1278237319.1278430900.15';
$lang['utmz'] = '156861353.1278430900.15.14.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/project/files/532';
$lang['qca'] = 'P0-958434736-1272799614549';
$lang['utmb'] = '156861353.1.10.1278430900';
$lang['utmc'] = '156861353';
?>