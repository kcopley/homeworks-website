<?php
$lang['automatedtask_failed'] = 'Автоматическая задача завершилась неудачно';
$lang['automatedtask_success'] = 'Автоматическая задача завершилась успешно';
$lang['clearcache_taskname'] = 'Очистить файлы кеша';
$lang['clearcache_taskdescription'] = 'Автоматически удалять файлы кеша, если они старше предустановленного количества дней';
$lang['testme'] = 'хе-хе :)';
$lang['qca'] = 'P0-1938388883-1277855813144';
$lang['utma'] = '156861353.429593658.1277855813.1287171834.1288916189.31';
$lang['utmz'] = '156861353.1286799193.22.13.utmccn=(organic)|utmcsr=google|utmctr=cmsmadesimple translation center|utmcmd=organic';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>