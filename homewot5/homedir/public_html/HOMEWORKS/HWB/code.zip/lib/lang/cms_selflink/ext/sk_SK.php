<?php
$lang['prev_label'] = 'Predch&aacute;dzaj&uacute;ca str&aacute;nka:';
$lang['next_label'] = 'Nasleduj&uacute;ca str&aacute;nka:';
$lang['utma'] = '156861353.1423109725.1280259016.1283883395.1284147995.32';
$lang['utmz'] = '156861353.1284147995.32.30.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/project/files/873';
$lang['qca'] = 'P0-748439131-1280259017524';
$lang['utmb'] = '156861353.2.10.1284147995';
$lang['utmc'] = '156861353';
?>