<?php
$lang['prev_label'] = 'Prethodna strana:';
$lang['next_label'] = 'Sledeća strana:';
$lang['qca'] = 'P0-1458450664-1284573084918';
$lang['utmz'] = '156861353.1285925682.82.14.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/project/list/module';
$lang['utma'] = '156861353.1164361908.1285153768.1286012149.1286015263.92';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>