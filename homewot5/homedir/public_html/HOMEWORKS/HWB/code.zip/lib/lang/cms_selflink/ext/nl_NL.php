<?php
$lang['prev_label'] = 'Vorige pagina:';
$lang['next_label'] = 'Volgende pagina:';
$lang['qca'] = 'P0-1530922099-1275938006999';
$lang['utma'] = '156861353.1240338921.1276019969.1285100963.1285158083.76';
$lang['utmz'] = '156861353.1284896478.74.58.utmcsr=forum.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/index.php';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>