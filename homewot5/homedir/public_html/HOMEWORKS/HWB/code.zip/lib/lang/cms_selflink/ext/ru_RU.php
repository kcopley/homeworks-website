<?php
$lang['prev_label'] = 'Предыдущая страница:';
$lang['next_label'] = 'Следущая страница:';
$lang['qca'] = 'P0-1938388883-1277855813144';
$lang['utma'] = '156861353.429593658.1277855813.1286806205.1286814378.25';
$lang['utmz'] = '156861353.1286799193.22.13.utmccn=(organic)|utmcsr=google|utmctr=cmsmadesimple translation center|utmcmd=organic';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>