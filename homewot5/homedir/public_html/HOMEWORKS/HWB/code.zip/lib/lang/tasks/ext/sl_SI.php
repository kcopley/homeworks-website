<?php
$lang['automatedtask_failed'] = 'Samodejna naloga ni uspela';
$lang['automatedtask_success'] = 'Samodejna naloga je uspela';
$lang['clearcache_taskname'] = 'Izprazni datoteke predpomnilnika';
$lang['clearcache_taskdescription'] = 'Samodejno izprazni datoteke iz direktorija predpomnilnika, ki so starej&scaron;i od vnaprej nastavljenem &scaron;tevilu dni';
$lang['testme'] = 'Ja uspelo je';
$lang['qca'] = 'P0-1458450664-1284573084918';
$lang['utmz'] = '156861353.1286352801.131.17.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms api docu';
$lang['utma'] = '156861353.1164361908.1285153768.1286727648.1286730193.160';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>