<?php
$lang['automatedtask_failed'] = 'Task automatico fallito';
$lang['automatedtask_success'] = 'Task automatico eseguito';
$lang['clearcache_taskname'] = 'Pulire i file di Cache';
$lang['clearcache_taskdescription'] = 'Automaticamente pulisce i file dalla cartella di cache che sono pi&ugrave; vecchi di un dato numero di giorni';
$lang['testme'] = 'eseguo';
$lang['qca'] = 'P0-250679722-1271187168764';
?>