<?php
$lang['automatedtask_failed'] = 'Automatizirani zadatak nije uspio';
$lang['automatedtask_success'] = 'Automatizirani zadatak izvr&scaron;en';
$lang['clearcache_taskname'] = 'Očisti cache datoteka';
$lang['clearcache_taskdescription'] = 'Automatski očisti datoteke iz cache direktorija starije od određenog broja dana';
$lang['testme'] = 'Hura! Rije&scaron;io sam...';
$lang['utma'] = '156861353.257390769.1275643143.1285994112.1286013984.106';
$lang['utmz'] = '156861353.1285738088.98.14.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['qca'] = 'P0-1982634597-1275643142955';
$lang['utmb'] = '156861353.2.10.1286013984';
$lang['utmc'] = '156861353';
?>