<?php
$lang['automatedtask_failed'] = '自動化されたタスクの実行に失敗しました。';
$lang['automatedtask_success'] = '自動化されたタスクが完了しました。';
$lang['clearcache_taskname'] = 'キャッシュファイルをクリアします。';
$lang['clearcache_taskdescription'] = '設定された日数で、古いキャッシュファイルを自動的に削除します。';
$lang['testme'] = 'woot を取った。';
$lang['utma'] = '156861353.1025915730.1283783986.1283783986.1283783986.1';
$lang['utmb'] = '156861353.1.10.1283783986';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1283783986.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-494958194-1283783986906';
?>