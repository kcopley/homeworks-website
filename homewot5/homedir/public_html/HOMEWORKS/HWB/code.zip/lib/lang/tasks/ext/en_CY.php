<?php
$lang['automatedtask_failed'] = 'Mae&#039;r Tasg Awtomatig wedi Methu';
$lang['automatedtask_success'] = 'Mae&#039;r Tasg Awtomatig wedi llwyddo';
$lang['clearcache_taskname'] = 'Clirio Ffeiliau Cache';
$lang['clearcache_taskdescription'] = 'Clirio ffeiliau yn Awtomatig o&#039;r cyfeiriadur cache os ydyn nhw&#039;n hŷn na nifer o ddyddiau rhagosodedig';
$lang['testme'] = 'woot Wedi&#039;i dderbyn';
$lang['qca'] = 'P0-1616678321-1262603060110';
$lang['utmz'] = '156861353.1287489336.33.6.utmcsr=wiki.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/index.php/Special:Search';
$lang['utma'] = '156861353.1150550259.1285890669.1287828027.1287832831.47';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.4.9.1287834037426';
?>