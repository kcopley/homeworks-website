<?php
$lang['automatedtask_failed'] = 'Fall&oacute; la Tarea Automatizada';
$lang['automatedtask_success'] = 'Tarea Automatizada Realizada';
$lang['clearcache_taskname'] = 'Limpiar Archivos Cach&eacute;';
$lang['clearcache_taskdescription'] = 'Eliminar de forma autom&aacute;tica aquellos archivos del directorio cach&eacute; que sean anteriores a un n&uacute;mero predeterminado de d&iacute;as';
$lang['testme'] = 'woot listo!';
$lang['utma'] = '156861353.541176812.1280673749.1284589166.1284592674.8';
$lang['utmz'] = '156861353.1280673749.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-1761112673-1280673750789';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>