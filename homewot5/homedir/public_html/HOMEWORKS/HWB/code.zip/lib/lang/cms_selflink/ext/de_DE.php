<?php
$lang['prev_label'] = 'Vorherige Seite:';
$lang['next_label'] = 'N&auml;chste Seite:';
$lang['utma'] = '156861353.1233875176.1284137789.1284137789.1284137789.1';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1284137789.1.1.utmccn=(referral)|utmcsr=forum.cmsmadesimple.org|utmcct=/|utmcmd=referral';
?>