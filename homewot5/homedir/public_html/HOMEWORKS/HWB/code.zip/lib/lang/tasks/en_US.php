<?php
$lang['automatedtask_failed'] = 'Automated Task Failed';
$lang['automatedtask_success'] = 'Automated Task Success';
$lang['clearcache_taskname'] = 'Clear Cache Files';
$lang['clearcache_taskdescription'] = 'Automatically clear files from cache directory that are older than a preset number of days';
$lang['testme'] = 'woot got it';
?>
