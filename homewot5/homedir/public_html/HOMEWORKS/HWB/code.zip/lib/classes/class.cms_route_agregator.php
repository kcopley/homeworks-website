<?php

class cms_route_agregator
{
  const FLAG_CONTENT = 'content';
  const FLAG_MODULES = 'modules';

  public function __construct($flags)
  {
  }
}

# vim:ts=4 sw=4 noet
?>